# DataCleaningHousing

[Dashboard](https://public.tableau.com/views/Airbnb_Project_16719958879230/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link)
